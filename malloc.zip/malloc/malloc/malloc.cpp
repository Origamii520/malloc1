﻿#include <iostream>
#include <cstdlib>
#include <cstring>
#include <cassert>

using namespace std;

class MyAllocator {
private:
    // 每个内存块的结构体
    struct Block {
        size_t size;  // 当前内存块的大小（不包括头部的Block结构）
        Block* next;  // 指向下一个空闲块的指针
    };

    Block* freeList;  // 空闲块链表的头指针

    // 内存对齐：确保内存块的起始地址满足特定的对齐要求
    size_t align(size_t size) {
        const size_t alignment = sizeof(void*);
        return (size + alignment - 1) & ~(alignment - 1);
    }

    // 合并相邻的空闲块
    void coalesce() {
        Block* current = freeList;
        while (current != nullptr && current->next != nullptr) {
            // 如果当前块与下一个块是相邻空闲块，进行合并
            if (reinterpret_cast<char*>(current) + sizeof(Block) + current->size == reinterpret_cast<char*>(current->next)) {
                current->size += sizeof(Block) + current->next->size; // 合并
                current->next = current->next->next;  // 更新链表
                cout << "Coalesced blocks into one block of size " << current->size << endl;
            }
            else {
                current = current->next;
            }
        }
    }

    // 输出当前空闲块链表的状态
    void printFreeList() {
        Block* current = freeList;
        cout << "Current free list: ";
        while (current != nullptr) {
            cout << "[Size: " << current->size << "] -> ";
            current = current->next;
        }
        cout << "NULL" << endl;
    }

public:
    MyAllocator() : freeList(nullptr) {}

    // 模拟 malloc
    void* my_malloc(size_t size) {
        if (size == 0) return nullptr;

        // 对齐处理：确保请求的大小满足对齐要求
        size = align(size);

        cout << "Requesting " << size << " bytes" << endl;

        // 在空闲块链表中查找合适的块
        Block* prev = nullptr;
        Block* curr = freeList;
        while (curr != nullptr) {
            if (curr->size >= size) {
                // 找到合适的块
                cout << "Allocated " << size << " bytes from free list" << endl;
                if (curr->size > size + sizeof(Block)) {
                    // 如果当前块比需要的块大，可以分割
                    Block* newBlock = reinterpret_cast<Block*>(reinterpret_cast<char*>(curr) + sizeof(Block) + size);
                    newBlock->size = curr->size - size - sizeof(Block);
                    newBlock->next = curr->next;

                    curr->size = size;
                    curr->next = nullptr;

                    // 将剩余的块加入空闲链表
                    if (prev == nullptr) {
                        freeList = newBlock;
                    }
                    else {
                        prev->next = newBlock;
                    }
                }
                else {
                    // 直接从空闲链表中移除当前块
                    if (prev == nullptr) {
                        freeList = curr->next;
                    }
                    else {
                        prev->next = curr->next;
                    }
                }
                printFreeList();  // 打印当前空闲块链表
                return reinterpret_cast<void*>(curr + 1);  // 返回内存块的实际地址
            }
            prev = curr;
            curr = curr->next;
        }

        // 如果没有找到合适的块，使用操作系统的 malloc 进行内存分配
        Block* newBlock = reinterpret_cast<Block*>(std::malloc(sizeof(Block) + size));
        if (!newBlock) return nullptr;

        newBlock->size = size;
        newBlock->next = nullptr;
        cout << "Allocated " << size << " bytes using system malloc" << endl;
        return reinterpret_cast<void*>(newBlock + 1);
    }

    // 模拟 free
    void my_free(void* ptr) {
        if (ptr == nullptr) return;

        Block* block = reinterpret_cast<Block*>(ptr) - 1;

        cout << "Freeing block of size " << block->size << endl;

        // 将释放的块加入空闲链表
        block->next = freeList;
        freeList = block;

        // 尝试合并空闲块
        coalesce();

        printFreeList();  // 打印当前空闲块链表
    }

    // 模拟 realloc
    void* my_realloc(void* ptr, size_t newSize) {
        if (ptr == nullptr) {
            return my_malloc(newSize);  // 如果原指针为空，直接分配新内存
        }

        if (newSize == 0) {
            my_free(ptr);  // 如果新大小为0，释放内存
            return nullptr;
        }

        Block* oldBlock = reinterpret_cast<Block*>(ptr) - 1;
        void* newPtr = my_malloc(newSize);
        if (newPtr) {
            std::memcpy(newPtr, ptr, std::min(oldBlock->size, newSize));  // 复制原数据
            my_free(ptr);  // 释放原内存
        }
        return newPtr;
    }

    ~MyAllocator() {
        while (freeList != nullptr) {
            Block* temp = freeList;
            freeList = freeList->next;
            std::free(temp);
        }
    }
};

int main() {
    MyAllocator allocator;

    // 测试 malloc 和 free
    void* p1 = allocator.my_malloc(100);
    void* p2 = allocator.my_malloc(50);
    allocator.my_free(p1);
    allocator.my_free(p2);

    // 测试 realloc
    p1 = allocator.my_malloc(200);
    p1 = allocator.my_realloc(p1, 300);

    // 使用完后释放
    allocator.my_free(p1);

    return 0;
}
